// O W L  C A R O U S E L - 1
var $owl1 = $('.owl-carousel-1');
$owl1.owlCarousel({
    loop: false, //Зацикливаем слайдер
    margin: 10, //Отступ от картино если выводите больше 1
    autoplay: false, //Автозапуск слайдера
    smartSpeed:1000, //Время движения слайда
    autoplayTimeout:2000, //Время смены слайда
    video: true,
    videoWidth: false, // Default false; Type: Boolean/Number
    videoHeight: false, // Default false; Type: Boolean/Number
    //center:true,
    lazyLoad: true,
    responsive:{ //Адаптация в зависимости от разрешения экрана
        0:{
            items: 1
        },
        600:{
            items: 2
        },
        1000:{
            items: 5
        }
    }
});

// Go to the next item
$('.next-button-1').click(function() {
    $owl1.trigger('next.owl.carousel');
});
// Go to the previous item
$('.prev-button-1').click(function() {
    // With optional speed parameter
    // Parameters has to be in square bracket '[]'
    $owl1.trigger('prev.owl.carousel', [300]);
});

// O W L  C A R O U S E L - 2
var $owl2 = $('.owl-carousel-2');
$owl2.owlCarousel({
    loop: false, //Зацикливаем слайдер
    margin: 10, //Отступ от картино если выводите больше 1
    autoplay: false, //Автозапуск слайдера
    smartSpeed:1000, //Время движения слайда
    autoplayTimeout:2000, //Время смены слайда
    video: true,
    videoWidth: false, // Default false; Type: Boolean/Number
    videoHeight: false, // Default false; Type: Boolean/Number
    //center:true,
    lazyLoad: true,
    responsive:{ //Адаптация в зависимости от разрешения экрана
        0:{
            items: 1
        },
        600:{
            items: 2
        },
        1000:{
            items: 5
        }
    }
});

// Go to the next item
$('.next-button-2').click(function() {
    $owl2.trigger('next.owl.carousel');
});
// Go to the previous item
$('.prev-button-2').click(function() {
    // With optional speed parameter
    // Parameters has to be in square bracket '[]'
    $owl2.trigger('prev.owl.carousel', [300]);
});

// O W L  C A R O U S E L  F I X
//$(window).resize(function () {
//    $('.owl-carousel-top').trigger('destroy.owl.carousel').removeClass('owl-carousel owl-loaded');
//    $('.owl-carousel-top').find('.owl-stage-outer').children().unwrap();
//});

// L I G H T  G A L L E R Y
// P H O T O
$('#lightgallery1, #lightgallery2').lightGallery({
    selector: '.item',
    download: false,
    thumbnail: 0
});
