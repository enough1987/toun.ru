
var taatrApp = angular.module("TaatrApp", []);
taatrApp.controller("AppCtrl", function ($scope, $log) {

    $log.debug(" AppCtrl page");

});
