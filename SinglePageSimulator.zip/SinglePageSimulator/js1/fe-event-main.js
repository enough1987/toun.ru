
// F E  E V E N T  M A I N

// P A G E  L O A D
addEventListener("load",function() {

	var loader = fe.g("i","loader");
	loader.style.display = "none";

	// Smooth page loading
	var feWrapper  = fe.g("i","fe-wrapper");
	feWrapper.style.transition = "opacity " + fe_s.loadSpeed + "s";
	feWrapper.style.opacity = "1";

	// User events
	var headerLogo = fe.g("i","header_logo");
	if(screen.height < 800)	{
		headerLogo = fe.g("i","header_logo");
		headerLogo.style.padding = "25px 0px 22px";
	}

	// var categoryButton = fe.g("i","category-button");
	// var category       = fe.g("i","category");
	// categoryButton.addEventListener("mouseover",function() {
	// 	fe.open( fe.g("i","category"));
	// 	console.log('1111');
	// });
	//
	// category.addEventListener("mouseleave",function() {
	// 	 fe.close( fe.g("i","category"));
	// });

	// headerLogo.addEventListener("mouseover",function() {
	// 	 fe.close( fe.g("i","category"));
	// });


	//var smallMenuButtton = fe.g("i","small-menu-buttton");
	//var btnState = false;
	//smallMenuButtton.addEventListener("click",function() {
	//	if (btnState) {
	//		$('#small-menu-buttton').toggleClass('inverse-small-menu-buttton');
	//		btnState = false;
	//	}
	//	if ($('#menu-small').css('display') == 'none' && $('#small-menu-buttton').hasClass('inverse-small-menu-buttton')) {
	//		$('#small-menu-buttton').toggleClass('inverse-small-menu-buttton');
	//		btnState = true;
	//	}
	//	fe.click( fe.g("i","menu-small"));
	//});

	var headerLogoImage = fe.g("i","header_logo_image");
	headerLogoImage.addEventListener("mouseover",function()	{
		var value = fe_g.logoDeg + 360;
		headerLogoImage.style.transform = "rotate(" + value.toString() + "deg)";
		fe_g.logoDeg = fe_g.logoDeg + 360 ;
	});
});

// P A G E  R E S I Z E
addEventListener("resize",function() {

});

// P A G E  S C R O L L
addEventListener("scroll",function() {

});
