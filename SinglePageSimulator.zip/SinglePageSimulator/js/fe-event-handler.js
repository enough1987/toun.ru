// F E   E V E N T  H A N D L E R

// F E   S E T T I N G
var fe_s = {
	loadSpeed : "0.8"
};

// F E  G L O B A L
var fe_g = {
	logoDeg : 0
}

// F E  E V E N T  H A N D L E R
var fe_eh = {
	
};
